<?php

	$koneksi = new mysqli("localhost", "id14315726_laundryapp", "Elvadanisa_241100", "id14315726_laundry_app");

?>